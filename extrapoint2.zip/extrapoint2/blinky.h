#include <stdint.h>

extern volatile uint8_t blinky_x;
extern volatile uint8_t blinky_y;