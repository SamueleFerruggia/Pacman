/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_timer.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    timer.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include <string.h>
#include "LPC17xx.h"
#include "timer.h"
#include "../GLCD/GLCD.h" 
#include "../TouchPanel/TouchPanel.h"
#include <stdio.h> /*for sprintf*/
#include "../sample.h"
#include "../CAN/CAN.h"
#include <stdlib.h> //per la abs

/******************************************************************************
** Function name:		Timer0_IRQHandler
**
** Descriptions:		Timer/Counter 0 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

uint8_t rand1, rand2;
int input;
volatile uint32_t elapsed_ticks;  // Contatore per il ritardo casuale
volatile uint32_t delay_ticks;   // Durata del ritardo casuale in tick

void checkTime();
volatile int down=0;

uint16_t SinTable[45] =
{
    410, 467, 523, 576, 627, 673, 714, 749, 778,
    799, 813, 819, 817, 807, 789, 764, 732, 694, 
    650, 602, 550, 495, 438, 381, 324, 270, 217,
    169, 125, 87 , 55 , 30 , 12 , 2  , 0  , 6  ,   
    20 , 41 , 70 , 105, 146, 193, 243, 297, 353
};

void TIMER0_IRQHandler (void)
{
	int i;
	// send from CAN1 to CAN2
	uint32_t packedData = ((uint32_t)time << 24) |  // Primi 8 bit (MSB)
												((uint32_t)vite << 16) |  // Secondi 8 bit
												(uint32_t)score;         // Ultimi 16 bit (LSB)
	
	uint8_t buffer[4];  // Buffer di 4 byte

	buffer[0] = (uint8_t)((packedData >> 24) & 0xFF);  // Byte 0 (MSB)
	buffer[1] = (uint8_t)((packedData >> 16) & 0xFF);  // Byte 1
	buffer[2] = (uint8_t)((packedData >> 8) & 0xFF);   // Byte 2
	buffer[3] = (uint8_t)(packedData & 0xFF);          // Byte 3 (LSB)
	
	for(i = 0; i<4; i++){
		CAN_TxMsg.data[i] = buffer[i];
	}
	
	CAN_TxMsg.len = 4;
	CAN_TxMsg.id = 2;
	CAN_TxMsg.format = STANDARD_FORMAT;
	CAN_TxMsg.type = DATA_FRAME;
	CAN_wrMsg (1, &CAN_TxMsg);               /* transmit message */
	
	if(down>=1){ 
		if((LPC_GPIO2->FIOPIN & (1<<10)) == 0){	/* INT0 pressed */
			switch(down){				
				case 2:	
					pausa = !pausa;
					schermataPausa();
					break;
				default:
					break;
			}
			down++;
		}
		else {	/* button released */
			down=0;			
			NVIC_EnableIRQ(EINT0_IRQn);							 /* enable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 20);     /* External interrupt 0 pin selection */
		}
	}
	
	GUI_Text(25, 25, (uint8_t *)score_txt, White, Black);
	GUI_Text(170, 25, (uint8_t *)time_txt, White, Black);
	GUI_Text(60, 300, (uint8_t *)vite_txt, White, Black);
	
  LPC_TIM0->IR = 1;			/* clear interrupt flag */
  return;
}


/******************************************************************************
** Function name:		Timer1_IRQHandler
**
** Descriptions:		Timer/Counter 1 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
void TIMER1_IRQHandler (void)
{
	elapsed_ticks++;  // Incrementa il contatore per il ritardo casuale

  // Verifica se il ritardo casuale � scaduto
  if (palloniCreati < MAX_PALLONI && elapsed_ticks >= delay_ticks) {
      creaPallone();       // Genera un pallone
      randomDelay();       // Calcola un nuovo ritardo casuale
  }
	scriviTime();
	checkTime();
	
	if (blinky_dead && blinky_respawn_timer > 0) {
        blinky_respawn_timer--;  // Decrementa il timer di respawn
				paura = 0;               // Resetta lo stato di paura
  }
	
	// Timer per lo stato di paura
  if (spaventato) { 
		if (paura_timer == 0) { // Se il timer � finito
				paura = 0;          // Fine della paura
        spaventato = 0;     // Resetta il flag di spavento
    } else {
				paura_timer--;      // Decrementa il timer
			}
	}
	
  LPC_TIM1->IR = 1;			/* clear interrupt flag */
  return;
}

/******************************************************************************
** Function name:		Timer2_IRQHandler
**
** Descriptions:		Timer/Counter 1 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
void TIMER2_IRQHandler (void)
{
	static int sineticks=0;
	/* DAC management */	
	static int currentValue; 
	currentValue = SinTable[sineticks];
	currentValue -= 410;
	currentValue /= 1;
	currentValue += 410;
	LPC_DAC->DACR = currentValue <<6;
	sineticks++;
	if(sineticks==45) sineticks=0;
	
  LPC_TIM2->IR = 1;			/* clear interrupt flag */
  return;
}

/******************************************************************************
** Function name:		Timer3_IRQHandler
**
** Descriptions:		Timer/Counter 1 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
void TIMER3_IRQHandler (void)
{
	disable_timer(2);
  LPC_TIM3->IR = 1;			/* clear interrupt flag */
  return;
}

void creaPallone() {
	//while palloniCreati < MAX_PALLONI, metti dentro il while anche randomDelay
	while (1) { // Ciclo finch� non trovi una cella valida
		rand1 = rand() % R; // Righe del labirinto
    rand2 = rand() % C; // Colonne del labirinto
    if (schermo[rand1][rand2] == 2) { // Verifica che sia una cella valida
			schermo[rand1][rand2] = 3;    // Imposta come pallone nel labirinto
      disegnaPallone(rand1, rand2);
      palloniCreati++;              // Incrementa il contatore dei palloni creati in totale
			palloni++;                    // Incrementa il contatore dei palloni a schermo
			palline--;
      break; // Esci dal ciclo
      }
   }
}

void randomDelay() {
    delay_ticks = (rand() % 4 + 2);  // Calcola un ritardo casuale tra 3 e 5 secondi
    elapsed_ticks = 0;  // Resetta il contatore dei tick
}

void scriviTime(){
	//char time_txt[3];
	time--;
	blinky_time++;
	//sprintf(time_txt, "%02u", time);
	//GUI_Text(170, 25, (uint8_t *)time_txt, White, Black);
}

void checkTime(){
	if(time == 0){
		haiPerso();
	}
}

uint32_t composeUint32(uint8_t first8, uint8_t second8, uint16_t last16) {
    uint32_t result = 0;

    result |= ((uint32_t)first8 << 24);   // Primi 8 bit nei bit 24-31
    result |= ((uint32_t)second8 << 16);  // Secondi 8 bit nei bit 16-23
    result |= (uint32_t)last16;           // Ultimi 16 bit nei bit 0-15

    return result;
}





/******************************************************************************
**                            End Of File
******************************************************************************/
