/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "LPC17xx.h"
#include "RIT.h"
#include "../sample.h"
#include "GLCD/GLCD.h" 
#include <stdio.h>
#include <string.h>
#include <stdlib.h> //per la abs
#include "../timer/timer.h"

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
volatile uint8_t active_task = 0;  // 0: Nessuna azione, 1-4: Direzioni, 5: INT0
volatile uint8_t pacman_timer = 0; // Contatore per il movimento di Pacman
volatile uint8_t pacman_velocity = 2; //velocit� di Pacman
volatile uint8_t blinky_velocity = 10; // Numero iniziale di colpi di RIT per muovere Blinky
volatile int paura_timer;
volatile uint8_t blinky_dead = 0;
volatile uint8_t blinky_respawn_timer = 0;
volatile uint8_t mangia;

void disegnaPacman(uint8_t riga, uint8_t colonna);
void cancellaPacman(uint8_t riga, uint8_t colonna);
void aggiornaPunteggio(uint8_t pos);
void haiVinto();

uint32_t next_threshold = 1000; // Il punteggio al quale ottenere una nuova vita

void cancellaBlinky(uint8_t riga, uint8_t colonna);
void disegnaBlinky(uint8_t riga, uint8_t colonna);
void disegnaBlinky2(uint8_t riga, uint8_t colonna);
void updateBlinky();
void manageBlinky();
int manhattanDistance(int x1, int y1, int x2, int y2);
void moveBlinky(int direction);
bool isValidMove(int x, int y, int i);
void attivaPaura();
void calculateAvailableDirections();
volatile uint8_t exited = 3;

void checkCollisionPacmanBlinky();


volatile uint8_t blinky_prev_cell = 0; // Salva il valore della cella precedente di Blinky
volatile uint8_t prev_direction = 0; // Salva il valore della cella precedente di Blinky
volatile uint8_t counter = 0;

// Array delle direzioni possibili (0 = UP, 1 = DOWN, 2 = LEFT, 3 = RIGHT)
bool availableDirections[4];

// Beat 1/4 = 1.6/4 seconds
#define RIT_SEMIMINIMA 8
#define RIT_MINIMA 16
#define RIT_INTERA 32

#define UPTICKS 1

// Megalovania
NOTE song[] = 
{
		{b4, time_semicroma}, {c5, time_semicroma},
    {d5, time_semicroma}, {b4, time_semicroma},
    {g4, time_semicroma}, {pause, time_semicroma},
    {g4, time_semicroma}, {e4, time_semicroma},
    {c4, time_croma}, {pause, time_croma},
};

void handle_task(uint8_t task) {  
	switch (task) {
        case 4:  // LEFT
					if(schermo[pacman_x-1][pacman_y] != 1){
						cancellaPacman(pacman_x, pacman_y);
						schermo[pacman_x][pacman_y] = 0;

        // Teletrasporto a sinistra
					if (schermo[pacman_x - 1][pacman_y] == 5) {
            pacman_x = 26; // Vai al lato opposto
					} else {
            pacman_x--;
						}
					aggiornaPunteggio(schermo[pacman_x][pacman_y]);
					disegnaPacman(pacman_x, pacman_y);
					schermo[pacman_x][pacman_y] = 4;
					}
            break;

        case 3:  // RIGHT
					if (schermo[pacman_x + 1][pacman_y] != 1) {
					cancellaPacman(pacman_x, pacman_y);
					schermo[pacman_x][pacman_y] = 0;

					// Teletrasporto a destra
					if (schermo[pacman_x + 1][pacman_y] == 6) {
							pacman_x = 1; // Vai al lato opposto
					} else {
							pacman_x++;
						}
					aggiornaPunteggio(schermo[pacman_x][pacman_y]);
					disegnaPacman(pacman_x, pacman_y);
					schermo[pacman_x][pacman_y] = 4;
					}
            break;

        case 2:  // DOWN
					if(schermo[pacman_x][pacman_y+1] != 1){
            cancellaPacman(pacman_x, pacman_y);
						schermo[pacman_x][pacman_y] = 0;
						pacman_y++;
							aggiornaPunteggio(schermo[pacman_x][pacman_y]);
						disegnaPacman(pacman_x, pacman_y);
						schermo[pacman_x][pacman_y] = 4;
					}
            break;

        case 1:  // UP
					if(schermo[pacman_x][pacman_y-1] != 1){
							cancellaPacman(pacman_x, pacman_y);
							schermo[pacman_x][pacman_y] = 0;
							pacman_y--;
							aggiornaPunteggio(schermo[pacman_x][pacman_y]);
							disegnaPacman(pacman_x, pacman_y);
							schermo[pacman_x][pacman_y] = 4;
					}
            break;
        default:
        break;
    }
}


void RIT_IRQHandler (void)
{		
		if(vite == 0)
			haiPerso();
		checkRIT();
		checkCollisionPacmanBlinky(); // Controllo costante della collisione Pac-Man vs Blinky
		// Controllo del joystick
    if ((LPC_GPIO1->FIOPIN & (1 << 29)) == 0 && active_task != 1) {
        active_task = 1;  // UP
    } else if ((LPC_GPIO1->FIOPIN & (1 << 26)) == 0 && active_task != 2) {
        active_task = 2;  // DOWN
    } else if ((LPC_GPIO1->FIOPIN & (1 << 28)) == 0 && active_task != 3) {
        active_task = 3;  // RIGHT
    } else if ((LPC_GPIO1->FIOPIN & (1 << 27)) == 0 && active_task != 4) {
        active_task = 4;  // LEFT
    }

    // Esecuzione della task attiva
    if (active_task != 0) {
        pacman_timer++;
        if (pacman_timer >= pacman_velocity) { // 5 (pacman_velocity) * 50ms = 250ms
            handle_task(active_task);
            pacman_timer = 0; // Resetta il timer
        }
    } 
		
		static int currentNote = 0;
		static int ticks = 0;
		
		//quando mangio Blinky ho un effetto sonoro
		if(mangia == 1){
			playNote(song[0]);
		}
		mangia = 0;
		
		//static int elapsedSeconds = 0; // Tempo trascorso in secondi
		if(pausa == false && !isNotePlaying())
		{
			++ticks;
			if(ticks == UPTICKS)
			{
				ticks = 0;
				playNote(song[currentNote++]);
			}
		}
		
		if(currentNote == (sizeof(song) / sizeof(song[0])))
		{
			 currentNote = 0; // Riavvia la canzone dall'inizio
			 //++elapsedSeconds; // Aggiungi un secondo (o la durata di una canzone completa)
		}
		
		/*if (elapsedSeconds >= 60) {
			disable_RIT(); // Interrompe il timer RIT
		}*/
		
		manageBlinky();
		
    // Reset del flag di interrupt
    LPC_RIT->RICTRL |= 0x1;

    return;
}

void cancellaPacman(uint8_t r, uint8_t c){
	int i = r*S + OFFSET_Y;
	int j = c*S + OFFSET_X;
	LCD_DrawLine(i, j, i, j+S-1, Black);
	LCD_DrawLine(i+S-7, j, i+S-7, j+S-1, Black);
	LCD_DrawLine(i+S-6, j, i+S-6, j+S-1, Black);
	LCD_DrawLine(i+S-5, j, i+S-5, j+S-1, Black);
	LCD_DrawLine(i+S-4, j, i+S-4, j+S-1, Black);
	LCD_DrawLine(i+S-3, j, i+S-3, j+S-1, Black);
	LCD_DrawLine(i+S-2, j, i+S-2, j+S-1, Black);
	LCD_DrawLine(i+S-1, j, i+S-1, j+S-1, Black);
}

void aggiornaPunteggio(uint8_t pos){
	if(pos == 2){
		score += 10;
		palline--;
	}
	if(pos == 3){
		score += 50;
		palloni--;
		attivaPaura();
	}
	if(pos == 7){
		mangia = 1; 
		score += 100;
	}
//	scriviScore();
	if (score >= next_threshold && vite < 3) {
		next_threshold += 1000; // Aggiorna il prossimo obiettivo
//		aggiornaVite();
		vite++;
  }
}

/*void aggiornaVite(){
	vite++;
	char vite_txt[2];
	sprintf(vite_txt, "%01u", vite);
	GUI_Text(60, 300, (uint8_t *)vite_txt, White, Black);
}*/

void checkRIT(){
	if(palline <= 0 && palloni <= 0){
		haiVinto();
	}
}

void haiVinto(){
	disable_RIT();
	disable_timer(1);
	disable_timer(0);
	active_task = 0;
	LCD_Clear(Black);
	GUI_Text(85, 160, (uint8_t *) "Hai vinto", Yellow, Black);
}

void haiPerso(){
	disable_RIT();
	disable_timer(1);
	disable_timer(0);
	active_task = 0;
	LCD_Clear(Black);
	GUI_Text(85, 160, (uint8_t *) "Hai perso", Red, Black);
}

void cancellaBlinky(uint8_t r, uint8_t c){
	int i = r*S + OFFSET_Y;
	int j = c*S + OFFSET_X;
	LCD_DrawLine(i+S-6, j, i+S-3, j, Black);
	LCD_DrawLine(i+S-7, j+S-7, i+S-2, j+S-7, Black);
	LCD_DrawLine(i, j+S-6, i+S-1, j+S-6, Black);
	LCD_DrawLine(i, j+S-5, i+S-1, j+S-5, Black); 
	LCD_DrawLine(i, j+S-4, i+S-1, j+S-4, Black); 
	LCD_DrawLine(i, j+S-3, i+S-1, j+S-3, Black);
	LCD_DrawLine(i, j+S-2, i+S-1, j+S-2, Black);
	LCD_DrawLine(i, j+S-1, i+S-1, j+S-1, Black);
}

// Funzione per verificare se la cella � valida (non � un muro)
bool isValidMove(int x, int y, int i) {
		if((prev_direction%2 == 0 && i-prev_direction == 1) || (prev_direction%2 == 1 && prev_direction-i == 1)){
			return false;
		}
		
		if((x == 5 || x == 22) && y == 14){
			return false; // Non facciamo passare Blinky per il teletrasporto
		}
	
    // Se exited == 0, le celle con valore 8 (porta) sono trattate come muri
    if (exited == 0 && schermo[x][y] == 8) {
			return false; // Trattiamo la porta come un muro
    }
    return (schermo[x][y] != 1); // 1 = Muro
}

// Calcola le direzioni disponibili
void calculateAvailableDirections() {
    availableDirections[0] = isValidMove(blinky_x - 1, blinky_y, 0); // 0 = UP
    availableDirections[1] = isValidMove(blinky_x + 1, blinky_y, 1); // 1 = DOWN
    availableDirections[2] = isValidMove(blinky_x, blinky_y - 1, 2); // 2 = LEFT
    availableDirections[3] = isValidMove(blinky_x, blinky_y + 1, 3); // 3 = RIGHT
}

// Muove Blinky verso la direzione scelta
void moveBlinky(int direction) {
    cancellaBlinky(blinky_x, blinky_y); // Rimuove Blinky dalla posizione attuale
    schermo[blinky_x][blinky_y] = blinky_prev_cell; 
    
    if (blinky_prev_cell == 2) {
        disegnaPallino(blinky_x, blinky_y); // Ridisegna pallina piccola
    } else if (blinky_prev_cell == 3) {
        disegnaPallone(blinky_x, blinky_y); // Ridisegna pallina grande
    }
		
    switch (direction) {
        case 0: blinky_x--; break; // 0 = UP
        case 1: blinky_x++; break; // 1 = DOWN
        case 2: blinky_y--; break; // 2 = LEFT
        case 3: blinky_y++; break; // 3 = RIGHT
    }
		
		// Aggiorna il valore della cella prima di spostarsi
		blinky_prev_cell = schermo[blinky_x][blinky_y];
		
		if(exited != 0){
			exited--;  // Blinky � uscito dalla porta
		}
		
		if(paura == 1){
			disegnaBlinky2(blinky_x, blinky_y); // Ridisegna Blinky nella nuova posizione
		}
		else{
			disegnaBlinky(blinky_x, blinky_y); // Ridisegna Blinky nella nuova posizione
		}
    schermo[blinky_x][blinky_y] = 7;   // Aggiorna la mappa con Blinky
		prev_direction = direction;
}

// Calcola la distanza manhattan tra due posizioni
int manhattanDistance(int x1, int y1, int x2, int y2) {
    return abs(x1 - x2) + abs(y1 - y2);
}

// Funzione principale per muovere Blinky verso Pac-Man
void updateBlinky() {
    calculateAvailableDirections();
    
    int bestDirection = -1;
    int optimalDistance = (paura == 0) ? 255 : -1; // Se paura == 0 minimizza, altrimenti massimizza

    // Prova ogni direzione valida e calcola la distanza da Pac-Man
    if (availableDirections[0]) { // 0 = UP
        int dist = manhattanDistance(blinky_x - 1, blinky_y, pacman_x, pacman_y);
        if ((paura == 0 && dist < optimalDistance) || (paura == 1 && dist > optimalDistance)) {
            optimalDistance = dist;
            bestDirection = 0;
        }
    }
    if (availableDirections[1]) { // 1 = DOWN
        int dist = manhattanDistance(blinky_x + 1, blinky_y, pacman_x, pacman_y);
        if ((paura == 0 && dist < optimalDistance) || (paura == 1 && dist > optimalDistance)) {
            optimalDistance = dist;
            bestDirection = 1;
        }
    }
    if (availableDirections[2]) { // 2 = LEFT
        int dist = manhattanDistance(blinky_x, blinky_y - 1, pacman_x, pacman_y);
        if ((paura == 0 && dist < optimalDistance) || (paura == 1 && dist > optimalDistance)) {
            optimalDistance = dist;
            bestDirection = 2;
        }
    }
    if (availableDirections[3]) { // 3 = RIGHT
        int dist = manhattanDistance(blinky_x, blinky_y + 1, pacman_x, pacman_y);
        if ((paura == 0 && dist < optimalDistance) || (paura == 1 && dist > optimalDistance)) {
            optimalDistance = dist;
            bestDirection = 3;
        }
    }
		
		if(exited != 0){
			bestDirection = 2; //forzo Blinky ad andare su
		}

    // Muove Blinky nella direzione migliore trovata
    if (bestDirection != -1) {
        moveBlinky(bestDirection);
    }
}

void manageBlinky() {
		if (blinky_dead == 1) {
				blinky_prev_cell = 0;
        // Se Blinky � morto, aspetta il timer di respawn
        if (blinky_respawn_timer > 0) {
            return;  // Non fa nulla finch� il timer non arriva a 0
        } else {
            // Timer scaduto, respawna Blinky
            blinky_x = 13;            // Respawn di Blinky
            blinky_y = 14;
            blinky_dead = 0;  // Blinky torna in vita
            blinky_respawn_timer = 0;  // Resetta il timer
            disegnaBlinky(blinky_x, blinky_y);  // Ridisegna Blinky
            schermo[blinky_x][blinky_y] = 7;    // Aggiorna la mappa con Blinky
        }
        return;  // Evita qualsiasi altro movimento durante il respawn
    }
    counter++;
    if (counter >= blinky_velocity) {  
        updateBlinky();
        counter = 0;
    }

    // Incremento della velocit� ogni 9 secondi
    if (blinky_time >= 9) { 
        if (blinky_velocity > 2) { // Impedisce che blinky_velocity scenda sotto 2 (stessa velocit� di Pacman)
            blinky_velocity--; // Aumenta la velocit� riducendo i colpi necessari
        }
        blinky_time = 0; // Resetta il timer di Blinky
    }
}

void attivaPaura() {
    paura = 1;          // Blinky entra nello stato di paura
    spaventato = 1;     // Flag per avviare il timer
    paura_timer = 10;   // Imposta il timer a 10 secondi
		prev_direction = 10;
}

//mortePacman, gestire la morte di Pacman
//pauraBlinky, gestire la morte di Blinky

void checkCollisionPacmanBlinky() {
    if (pacman_x == blinky_x && pacman_y == blinky_y) {
        if (paura == 1) { // Caso Blinky Spaventato
            aggiornaPunteggio(schermo[pacman_x][pacman_y]);  // Aggiungi 100 punti
            paura_timer = 10;        	 // Resetta il timer della paura
            blinky_dead = 1;  				 // Blinky viene dichiarato morto
            blinky_respawn_timer = 3;  // Imposta il timer di respawn a 3 secondi
        } else { // Caso Blinky Non Spaventato
						cancellaPacman(pacman_x, pacman_y);
            vite--;          // Pac-Man perde una vita
            pacman_x = 14;            // Respawn di Pac-Man
            pacman_y = 23;
            blinky_x = 13;            // Respawn di Blinky
            blinky_y = 14;
            schermo[pacman_x][pacman_y] = 4; // Aggiorna la cella con Pac-Man
            schermo[blinky_x][blinky_y] = 7; // Aggiorna la cella con Blinky
            //pausa = 1;               // Mette in pausa il gioco
						disegnaPacman(pacman_x, pacman_y);
        }
				exited = 3;
    }
}


/******************************************************************************
**                            End Of File
******************************************************************************/
