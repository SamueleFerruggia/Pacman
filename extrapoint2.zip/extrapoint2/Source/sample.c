/****************************************Copyright (c)****************************************************
**                                      
**                                 http://www.powermcu.com
**
**--------------File Info---------------------------------------------------------------------------------
** File name:               main.c
** Descriptions:            The GLCD application function
**
**--------------------------------------------------------------------------------------------------------
** Created by:              AVRman
** Created date:            2010-11-7
** Version:                 v1.0
** Descriptions:            The original version
**
**--------------------------------------------------------------------------------------------------------
** Modified by:             Paolo Bernardi
** Modified date:           03/01/2020
** Version:                 v2.0
** Descriptions:            basic program for LCD and Touch Panel teaching
**
*********************************************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "LPC17xx.h"
#include "GLCD/GLCD.h" 
#include "TouchPanel/TouchPanel.h"
#include "timer/timer.h"
#include "../sample.h"
#include "RIT/RIT.h"
#include "joystick/joystick.h"
#include <stdio.h>
#include <string.h>


#ifdef SIMULATOR
extern uint8_t ScaleFlag; // <- ScaleFlag needs to visible in order for the emulator to find the symbol (can be placed also inside system_LPC17xx.h but since it is RO, it needs more work)
#endif

void disegnaMappa(uint8_t r, uint8_t c);
void disegnaMuro(uint8_t riga, uint8_t colonna);
extern void disegnaPacman(uint8_t riga, uint8_t colonna);
extern void disegnaBlinky(uint8_t riga, uint8_t colonna);
extern void disegnaBlinky2(uint8_t riga, uint8_t colonna);
void disegnaPallino(uint8_t riga, uint8_t colonna);
void init_rand_seed();

volatile uint8_t pacman_x; 
volatile uint8_t pacman_y;
volatile uint8_t blinky_x; 
volatile uint8_t blinky_y;
volatile uint8_t palloniCreati;
volatile uint32_t score;
volatile uint8_t time = 61;
volatile uint8_t blinky_time = 0;
volatile uint8_t vite = 1;
volatile uint8_t palline = 0;
volatile uint8_t palloni = 0;
volatile uint8_t paura = 0;
volatile uint8_t spaventato = 0;
volatile bool pausa = true;

// vuoto = 0
// muro = 1
// pallini = 2
// palloni = 3
// pacman = 4
// teleport d = 5
// teleport s = 6
// blinky = 7
// porte blinky = 8


uint8_t schermo[R][C] = { {1,1,1, 1,1,1, 1,1,1, 1,0,0, 0,1,5, 1,0,0, 0,1,1, 1,1,1, 1,1,1, 1,1,1, 1},
													{1,2,2, 2,2,2, 2,2,2, 1,0,0, 0,1,0, 1,0,0, 0,1,2, 2,2,2, 1,1,2, 2,2,2, 1},
													{1,2,1, 1,1,2, 1,1,2, 1,0,0, 0,1,0, 1,0,0, 0,1,2, 1,1,2, 1,1,2, 1,1,2, 1},
													{1,2,1, 1,1,2, 1,1,2, 1,0,0, 0,1,0, 1,0,0, 0,1,2, 1,1,2, 2,2,2, 1,1,2, 1},
													{1,2,1, 1,1,2, 1,1,2, 1,0,0, 0,1,0, 1,0,0, 0,1,2, 1,1,1, 1,1,2, 1,1,2, 1},
													{1,2,1, 1,1,2, 1,1,2, 1,1,1, 1,1,0, 1,1,1, 1,1,2, 1,1,1, 1,1,2, 1,1,2, 1},
													{1,2,2, 2,2,2, 2,2,2, 2,2,2, 2,2,0, 2,2,2, 2,2,2, 2,2,2, 2,2,2, 1,1,2, 1},
													{1,2,1, 1,1,2, 1,1,1, 1,1,1, 1,1,0, 1,1,1, 1,1,2, 1,1,2, 1,1,1, 1,1,2, 1},
													{1,2,1, 1,1,2, 1,1,1, 1,1,1, 1,1,0, 1,1,1, 1,1,2, 1,1,2, 1,1,1, 1,1,2, 1},
													{1,2,1, 1,1,2, 2,2,2, 1,1,0, 0,0,0, 0,0,0, 0,0,2, 1,1,2, 2,2,2, 1,1,2, 1},
													{1,2,1, 1,1,2, 1,1,2, 1,1,0, 1,1,1, 1,1,0, 1,1,2, 1,1,2, 1,1,2, 1,1,2, 1},
													{1,2,1, 1,1,2, 1,1,2, 1,1,0, 1,0,0, 0,1,0, 1,1,2, 1,1,2, 1,1,2, 1,1,2, 1},
													{1,2,2, 2,2,2, 1,1,0, 0,0,0, 1,0,0, 0,1,0, 1,1,2, 2,2,2, 1,1,2, 2,2,2, 1},
													{1,1,1, 1,1,2, 1,1,1, 1,1,0, 8,0,7, 0,1,0, 1,1,1, 1,1,0, 1,1,1, 1,1,2, 1},
													{1,1,1, 1,1,2, 1,1,1, 1,1,0, 8,0,0, 0,1,0, 1,1,1, 1,1,4, 1,1,1, 1,1,2, 1},
													{1,2,2, 2,2,2, 1,1,0, 0,0,0, 1,0,0, 0,1,0, 1,1,2, 2,2,2, 1,1,2, 2,2,2, 1},
													{1,2,1, 1,1,2, 1,1,2, 1,1,0, 1,0,0, 0,1,0, 1,1,2, 1,1,2, 1,1,2, 1,1,2, 1},
													{1,2,1, 1,1,2, 1,1,2, 1,1,0, 1,1,1, 1,1,0, 1,1,2, 1,1,2, 1,1,2, 1,1,2, 1},
													{1,2,1, 1,1,2, 2,2,2, 1,1,0, 0,0,0, 0,0,0, 0,0,2, 1,1,2, 2,2,2, 1,1,2, 1},
													{1,2,1, 1,1,2, 1,1,1, 1,1,1, 1,1,0, 1,1,1, 1,1,2, 1,1,2, 1,1,1, 1,1,2, 1},
													{1,2,1, 1,1,2, 1,1,1, 1,1,1, 1,1,0, 1,1,1, 1,1,2, 1,1,2, 1,1,1, 1,1,2, 1},
													{1,2,2, 2,2,2, 2,2,2, 2,2,2, 2,2,0, 2,2,2, 2,2,2, 2,2,2, 2,2,2, 1,1,2, 1},
													{1,2,1, 1,1,2, 1,1,2, 1,1,1, 1,1,0, 1,1,1, 1,1,2, 1,1,1, 1,1,2, 1,1,2, 1},
													{1,2,1, 1,1,2, 1,1,2, 1,0,0, 0,1,0, 1,0,0, 0,1,2, 1,1,1, 1,1,2, 1,1,2, 1},
													{1,2,1, 1,1,2, 1,1,2, 1,0,0, 0,1,0, 1,0,0, 0,1,2, 1,1,2, 2,2,2, 1,1,2, 1},
													{1,2,1, 1,1,2, 1,1,2, 1,0,0, 0,1,0, 1,0,0, 0,1,2, 1,1,2, 1,1,2, 1,1,2, 1},
													{1,2,2, 2,2,2, 2,2,2, 1,0,0, 0,1,0, 1,0,0, 0,1,2, 2,2,2, 1,1,2, 2,2,2, 1},
													{1,1,1, 1,1,1, 1,1,1, 1,0,0, 0,1,6, 1,0,0, 0,1,1, 1,1,1, 1,1,1, 1,1,1, 1}};
														 
int main(void)
{
  SystemInit();  												/* System Initialization (i.e., PLL)  */
	CAN_Init();
  LCD_Initialization();
	
	TP_Init();
	
	LCD_Clear(Black);
	//GUI_Text(0, 280, (uint8_t *) " touch here : 1 sec to clear  ", Red, White);
	//LCD_DrawLine(0, 0, 200, 200, White);
	//init_timer(0, 0x1312D0 ); 						/* 50ms * 25MHz = 1.25*10^6 = 0x1312D0 */
	//init_timer(0, 0x6108 ); 						  /* 1ms * 25MHz = 25*10^3 = 0x6108 */
	//init_timer(0, 0x4E2 ); 						    /* 500us * 25MHz = 1.25*10^3 = 0x4E2 */
	init_timer(0, 2500000);                /* 0.1 sec, lo utilizzo solo per il tasto int0 e il CAN */
	enable_timer(0);
	//startTimer1();
	//startRIT();
	
	disegnaMappa(R, C);
	BUTTON_init();
	GUI_Text(170, 10, (uint8_t *) "Time", White, Black);
	GUI_Text(95, 0, (uint8_t *) "Pacman", White, Black);
	GUI_Text(25, 10, (uint8_t *) "Score", White, Black);
	GUI_Text(15, 300, (uint8_t *) "Vite:", White, Black);
	schermataPausa();
	//ADC_init();      // il timer 2 e 3 a priorit� zero potrebbero rallentare il timer di gioco (i 60 secondi)
	
//	scriviScore();
	scriviTime();
//	aggiornaVite();
	joystick_init();											/* Joystick Initialization            */
	init_rand_seed();
	
	LPC_SC->PCON |= 0x1;									/* power-down	mode										*/
	LPC_SC->PCON &= ~(0x2);	

	LPC_PINCON->PINSEL1 |= (1<<21);
	LPC_PINCON->PINSEL1 &= ~(1<<20);
	LPC_GPIO0->FIODIR |= (1<<26);
	
  while (1)	
  {
		__ASM("wfi");
  }
}

void disegnaMappa(uint8_t r, uint8_t c){
	uint8_t i, j;
	for(i = 0; i<r; i++){
		for(j = 0; j<c; j++){
			uint8_t cella = schermo[i][j];
			switch(cella){
				case 1: 										//muro
					disegnaMuro(i, j);
				break;
				case 2:											//pallini
					disegnaPallino(i, j);
					palline++;
				break;
				case 4:											//pacman
					pacman_x = i;
					pacman_y = j;
					disegnaPacman(i, j);
				break;
				case 7:											//pacman
					blinky_x = i;
					blinky_y = j;
					disegnaBlinky(i, j);
				break;
				default:				
				break;
			}
		}
	}
}

void disegnaMuro(uint8_t r, uint8_t c){
	int i = r*S + OFFSET_Y;
	int j = c*S + OFFSET_X;
	if(c == 0 || schermo[r][c-1] != 1){// Controllo bordo sinistro
		LCD_DrawLine(i, j, i+S-1, j, Blue);
	}
	if(c == C-1 || schermo[r][c+1] != 1){// Controllo bordo destro
		LCD_DrawLine(i, j+S-1, i+S-1, j+S-1, Blue);
	}
	if(r == 0 || schermo[r-1][c] != 1){// Controllo bordo superiore
		LCD_DrawLine(i, j, i, j+S-1, Blue); 
	}
	if(r == R-1 || schermo[r+1][c] != 1){// Controllo bordo inferiore
		LCD_DrawLine(i+S-1, j, i+S-1, j+S-1, Blue); 
	}

}	

void disegnaPacman(uint8_t r, uint8_t c){
	int i = r*S + OFFSET_Y;
	int j = c*S + OFFSET_X;
	LCD_DrawLine(i, j+S-6, i, j+S-3, Yellow);
	LCD_DrawLine(i+S-7, j+S-7, i+S-7, j+S-2, Yellow);
	LCD_DrawLine(i+S-6, j, i+S-6, j+S-1, Yellow);
	LCD_DrawLine(i+S-5, j, i+S-5, j+S-1, Yellow);
	LCD_DrawLine(i+S-4, j, i+S-4, j+S-1, Yellow);
	LCD_DrawLine(i+S-3, j, i+S-3, j+S-1, Yellow);
	LCD_DrawLine(i+S-2, j+S-7, i+S-2, j+S-2, Yellow);
	LCD_DrawLine(i+S-1, j+S-6, i+S-1, j+S-3, Yellow);
}

void disegnaPallino(uint8_t r, uint8_t c){
	int i = r*S + OFFSET_Y;
	int j = c*S + OFFSET_X;
	LCD_DrawLine(i+S-4, j+S-4, i+S-4, j+S-4, White);
	/*LCD_DrawLine(i+S-5, j+S-2, i+S-5, j+S-4, White);
	  LCD_DrawLine(i+S-4, j+S-2, i+S-4, j+S-4, White);
	  LCD_DrawLine(i+S-3, j+S-2, i+S-3, j+S-4, White);    codice palloni    */
}

void disegnaPallone(uint8_t r, uint8_t c){
	int i = r*S + OFFSET_Y;
	int j = c*S + OFFSET_X;
	//LCD_DrawLine(i+S-4, j+S-3, i+S-4, j+S-3, White);    codice pallini
	LCD_DrawLine(i+S-5, j+S-3, i+S-5, j+S-5, White);
	LCD_DrawLine(i+S-4, j+S-3, i+S-4, j+S-5, White);
	LCD_DrawLine(i+S-3, j+S-3, i+S-3, j+S-5, White);
}


void init_rand_seed() {
    uint32_t timer_value = LPC_TIM1->TC; // Leggi il valore del contatore di un timer
    srand(timer_value); // Usa il valore del timer come seed
}

/*void scriviScore(){
	char score_txt[6];
	sprintf(score_txt, "%05u", score);
	GUI_Text(25, 25, (uint8_t *)score_txt, White, Black);
}*/

void startTimer1(){
	init_timer(1, 25000000);                /* 1 secondo, serve per il timer e creazione di palloni */
	enable_timer(1);
}

void startRIT(int frequency){
	init_RIT(frequency);									 
	enable_RIT();													/* RIT enabled */
}

void schermataPausa(){
	if(pausa){
		GUI_Text(170, 300, (uint8_t *) "PAUSA", Red, White);
		startRIT(0xFFFFFFFF);
		//NVIC_DisableIRQ(RIT_IRQn);
		//NVIC_DisableIRQ(TIMER1_IRQn);
		disable_timer(1);
		
		//per i bug grafici prova a fare reset_RIT() o a mettere la GUI_Text dopo l'enable
		
	} else{
		GUI_Text(170, 300, (uint8_t *) "     ", Black, Black);
		startTimer1();
		startRIT(5000000);                   /* RIT Initialization 0.2 sec (5000000)      	*/
		//NVIC_EnableIRQ(TIMER1_IRQn);
		//NVIC_EnableIRQ(RIT_IRQn);
	}
}

void disegnaBlinky(uint8_t r, uint8_t c){
	int i = r*S + OFFSET_Y;
	int j = c*S + OFFSET_X;
	LCD_DrawLine(i+S-6, j, i+S-3, j, Red);
	LCD_DrawLine(i+S-7, j+S-7, i+S-2, j+S-7, Red);
	
	LCD_DrawLine(i, j+S-6, i+S-7, j+S-6, Red); //fronte sinistra
	LCD_DrawLine(i+S-6, j+S-6, i+S-6, j+S-6, Blue); //occhio sinistro
	LCD_DrawLine(i+S-5, j+S-6, i+S-4, j+S-6, Red); //naso
	LCD_DrawLine(i+S-3, j+S-6, i+S-3, j+S-6, Blue); //occhio destro
	LCD_DrawLine(i+S-2, j+S-6, i+S-1, j+S-6, Red); //fronte destra

	LCD_DrawLine(i, j+S-5, i+S-7, j+S-5, Red); //fronte sinistra
	LCD_DrawLine(i+S-6, j+S-5, i+S-6, j+S-5, Blue); //occhio sinistro
	LCD_DrawLine(i+S-5, j+S-5, i+S-4, j+S-5, Red); //naso
	LCD_DrawLine(i+S-3, j+S-5, i+S-3, j+S-5, Blue); //occhio destro
	LCD_DrawLine(i+S-2, j+S-5, i+S-1, j+S-5, Red); //fronte destra

	LCD_DrawLine(i, j+S-4, i+S-1, j+S-4, Red); //corpo di Blinky
	LCD_DrawLine(i, j+S-3, i+S-1, j+S-3, Red);
	LCD_DrawLine(i, j+S-2, i+S-1, j+S-2, Red);

	LCD_DrawLine(i, j+S-1, i, j+S-1, Red);
	LCD_DrawLine(i+S-6, j+S-1, i+S-6, j+S-1, Red);
	LCD_DrawLine(i+S-3, j+S-1, i+S-3, j+S-1, Red);
	LCD_DrawLine(i+S-1, j+S-1, i+S-1, j+S-1, Red);
}

void disegnaBlinky2(uint8_t r, uint8_t c){
	int i = r*S + OFFSET_Y;
	int j = c*S + OFFSET_X;
	LCD_DrawLine(i+S-6, j, i+S-3, j, Blue);
	LCD_DrawLine(i+S-7, j+S-7, i+S-2, j+S-7, Blue);
	
	LCD_DrawLine(i, j+S-6, i+S-7, j+S-6, Blue); //fronte sinistra
	LCD_DrawLine(i+S-6, j+S-6, i+S-6, j+S-6, Red); //occhio sinistro
	LCD_DrawLine(i+S-5, j+S-6, i+S-4, j+S-6, Blue); //naso
	LCD_DrawLine(i+S-3, j+S-6, i+S-3, j+S-6, Red); //occhio destro
	LCD_DrawLine(i+S-2, j+S-6, i+S-1, j+S-6, Blue); //fronte destra

	LCD_DrawLine(i, j+S-5, i+S-7, j+S-5, Blue); //fronte sinistra
	LCD_DrawLine(i+S-6, j+S-5, i+S-6, j+S-5, Red); //occhio sinistro
	LCD_DrawLine(i+S-5, j+S-5, i+S-4, j+S-5, Blue); //naso
	LCD_DrawLine(i+S-3, j+S-5, i+S-3, j+S-5, Red); //occhio destro
	LCD_DrawLine(i+S-2, j+S-5, i+S-1, j+S-5, Blue); //fronte destra

	LCD_DrawLine(i, j+S-4, i+S-1, j+S-4, Blue); //corpo di Blinky
	LCD_DrawLine(i, j+S-3, i+S-1, j+S-3, Blue);
	LCD_DrawLine(i, j+S-2, i+S-1, j+S-2, Blue);

	LCD_DrawLine(i, j+S-1, i, j+S-1, Blue);
	LCD_DrawLine(i+S-6, j+S-1, i+S-6, j+S-1, Blue);
	LCD_DrawLine(i+S-3, j+S-1, i+S-3, j+S-1, Blue);
	LCD_DrawLine(i+S-1, j+S-1, i+S-1, j+S-1, Blue);
}


/*********************************************************************************************************
      END FILE
*********************************************************************************************************/
