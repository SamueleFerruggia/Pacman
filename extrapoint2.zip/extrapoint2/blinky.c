#include "../blinky.h"
#include "../sample.h"
#include "GLCD/GLCD.h" 

extern void disegnaBlinky(uint8_t riga, uint8_t colonna);

void disegnaBlinky(uint8_t r, uint8_t c){
	int i = r*S + OFFSET_Y;
	int j = c*S + OFFSET_X;
	LCD_DrawLine(i+S-6, j, i+S-3, j, Red);
	LCD_DrawLine(i+S-7, j+S-7, i+S-2, j+S-7, Red);
	
	LCD_DrawLine(i, j+S-6, i+S-7, j+S-6, Red); //fronte sinistra
	LCD_DrawLine(i+S-6, j+S-6, i+S-6, j+S-6, Blue); //occhio sinistro
	LCD_DrawLine(i+S-5, j+S-6, i+S-4, j+S-6, Red); //naso
	LCD_DrawLine(i+S-3, j+S-6, i+S-3, j+S-6, Blue); //occhio destro
	LCD_DrawLine(i+S-2, j+S-6, i+S-1, j+S-6, Red); //fronte destra

	LCD_DrawLine(i, j+S-5, i+S-7, j+S-5, Red); //fronte sinistra
	LCD_DrawLine(i+S-6, j+S-5, i+S-6, j+S-5, Blue); //occhio sinistro
	LCD_DrawLine(i+S-5, j+S-5, i+S-4, j+S-5, Red); //naso
	LCD_DrawLine(i+S-3, j+S-5, i+S-3, j+S-5, Blue); //occhio destro
	LCD_DrawLine(i+S-2, j+S-5, i+S-1, j+S-5, Red); //fronte destra

	LCD_DrawLine(i, j+S-4, i+S-1, j+S-4, Red); //corpo di Blinky
	LCD_DrawLine(i, j+S-3, i+S-1, j+S-3, Red);
	LCD_DrawLine(i, j+S-2, i+S-1, j+S-2, Red);

	LCD_DrawLine(i, j+S-1, i, j+S-1, Red);
	LCD_DrawLine(i+S-6, j+S-1, i+S-6, j+S-1, Red);
	LCD_DrawLine(i+S-3, j+S-1, i+S-3, j+S-1, Red);
	LCD_DrawLine(i+S-1, j+S-1, i+S-1, j+S-1, Red);
}