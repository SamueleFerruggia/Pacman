#include <stdint.h>
#include <stdbool.h>

#define R 28
#define C 31
#define S 8
#define MAX_PALLONI 6
extern uint8_t schermo[R][C];
#define OFFSET_X 44  // Offset verso basso
#define OFFSET_Y 8  // Offset verso destra
extern volatile uint32_t score;
extern volatile uint8_t time;
extern volatile uint8_t palloniCreati;
extern volatile uint8_t vite;
extern volatile uint8_t palline;
extern volatile uint8_t palloni;
extern volatile uint8_t active_task;
extern volatile bool pausa;
extern volatile uint8_t blinky_x;
extern volatile uint8_t blinky_y;
extern volatile uint8_t pacman_x;
extern volatile uint8_t pacman_y;
extern volatile uint32_t elapsed_ticks;  // Contatore per il ritardo casuale
extern volatile uint32_t delay_ticks;   // Durata del ritardo casuale in tick
extern volatile uint8_t pacman_timer; // Contatore per il movimento di Pac-Man
extern volatile uint8_t pacman_velocity;
extern volatile uint8_t blinky_velocity; // Numero iniziale di colpi di RIT per muovere Blinky
extern volatile uint8_t blinky_time; // timer di Blinky
extern volatile uint8_t exited;       //variabile che mi serve per capire se Blinky � uscito o meno dalla casetta
extern volatile uint8_t paura;
extern volatile uint8_t spaventato;
extern volatile int paura_timer;
extern volatile uint8_t blinky_dead;        // Indica se Blinky � morto (0 = Vivo, 1 = Morto)
extern volatile uint8_t blinky_respawn_timer;  // Timer per il respawn di Blinky (in secondi)
extern volatile	char score_txt[6];
extern volatile	char time_txt[3];
extern volatile	char vite_txt[2];



//void scriviScore();
void scriviTime();
void disegnaPallone(uint8_t riga, uint8_t colonna);
void creaPallone();
void randomDelay();
//void aggiornaVite();
void startTimer1();
void startRIT(int frequency);
void checkRIT();
void schermataPausa();
void handle_task(uint8_t task);
void haiPerso();
uint32_t composeUint32(uint8_t first8, uint8_t second8, uint16_t last16);